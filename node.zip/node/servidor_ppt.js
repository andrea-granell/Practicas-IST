var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);

var PUERTO = 8080;
server.listen(PUERTO, function() {
    console.log('Servidor corriendo en http://localhost:' + PUERTO);
});

app.use(express.static('../html')); // directorio de documentos estáticos


// Estas variables serán comunes (las mismas) en todas las conexiones

//Nombres clientes
let names = [];

// indice de cliente
let n_cli = 0;

// Array -de dos posiciones- con la apuesta de cada cliente
let apuestas = [];

// Array booleano indicando si ya han apostado o no cada cliente
let apostado = [false, false];

// Array booleano indicando si ya han clicado nueva partida cada cliente, o no
let nueva_partida = [false, false];


// Establecimiento de conexión con cliente.
// Debe pensarse que la acción se realiza para cada cliente de forma replicada,
// Cada conexión con cada cliente, tiene su espacio de variables propio
// para aquellas variables declaradas localmente en la función 
// (mi_n_cli y socket). Sin embargo, variables como n_cli, apuestas, apostado o
// nueva_partida son globales, y por tanto comunes e idénticas para todos.
io.on('connection', function(socket) {
    let mi_n_cli = n_cli; // Cada conexión tendrá su "mi_n_cli"
    n_cli++; // Sin embargo, n_cli es la misma variable para todos
    apostado = [false, false];
    apuestas = [];
    // Mensaje de tipo 'identificativo' con el valor de mi_n_cli
    socket.emit('identificativo', mi_n_cli);

    //Recepcion de nombre propio del cliente correspondiente a mi_n_cli
    socket.on('nombre', function(nom) {
        names[mi_n_cli] = nom;
        console.log('Cliente conectado, mi_n_cli: ' + mi_n_cli + ', nombre: ' + names[mi_n_cli]);
        //INTERROGANTES DE ESPERA, fin de la espera
        if (n_cli == 2) {
            io.emit('preparados');
            io.emit('nombres', names);
            console.log("nombres enviados a los jugadores: " + names[0] + " " + names[1]) //Han de tomar como propio el del indice identificativo mi_n_cli
        }
    })


    socket.on('apuesta', function(eleccion) {
        console.log('apuesta recibida de ' + mi_n_cli + ': ', eleccion);
        apuestas[mi_n_cli] = eleccion;

        /* Deberían actualizarse los arrays apuestas y apostado
        Si ambas componentes de apostado estan a true, hay que difundir
        las apuestas con un mensaje de tipo 'resultados' */
        if ((apuestas[0] == 'piedra') || (apuestas[0] == 'papel') || (apuestas[0] == 'tijera')) {
            apostado[0] = true;
            console.log('Jugador 0: apostado = ' + apostado[0] + ', apuesta: ' + apuestas[0])
        } else { apostado[0] = false; }
        if ((apuestas[1] == 'piedra') || (apuestas[1] == 'papel') || (apuestas[1] == 'tijera')) {
            apostado[1] = true;
            console.log('Jugador 1: apostado = ' + apostado[1] + ', apuesta: ' + apuestas[1])
        } else { apostado[1] = false; }

        if ((apostado[0] == true) && (apostado[1] == true)) {
            io.emit('resultados', apuestas); //envia a todos los cliente el resutlado
            console.log('APUESTAS HECHAS, RESULTADOS ENVIADOS');
        } else {
            console.log('no se han enviado los resultados');
            console.log('Jugador 0: ' + apostado[0] + 'Jugador 1: ' + apostado[1]);
        }

        io.emit('apostado', apostado);

    })

    socket.on('jugar_otra_vez', function() {
        console.log('El jugador ' + mi_n_cli + ' quiere jugar otra vez.')
        nueva_partida[mi_n_cli] = true;
        if (nueva_partida[0] && nueva_partida[1]) {
            console.log('Difundiendo peticion de nueva_partida');
            apostado = [false, false];
            nueva_partida = [false, false];
            apuestas = [];
            io.emit('nueva_partida');
        }
        io.emit('esperando', nueva_partida);
    })

    socket.on('disconnect', function() {
        names[mi_n_cli] = '';
        n_cli--;
        console.log('Usuario desconectado, ahora n_cli: ' + n_cli);
        io.emit('abandono');
    })
});



console.log('Script servidor_ppt.js ejecutado')